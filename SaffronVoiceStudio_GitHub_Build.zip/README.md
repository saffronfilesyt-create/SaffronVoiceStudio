# Saffron Voice Studio — GitHub Cloud Build

This project uses GitHub Actions as a cloud Android build machine.

The current build target is the open-source Pocket TTS Android Engine, which provides
offline ARM64 Android TTS and reference-audio voice cloning. The Hindi model is
installed separately because model weights are large and have separate licensing.

## Build
1. Upload this project to your GitHub repository.
2. Open Actions.
3. Run **Build Android APK**.
4. Download the APK from the workflow's Artifacts section.

Important: this first ZIP is an **engine/build test**, not yet the final Saffron-branded
5-voice story studio. It is intentionally kept honest so we don't give you a UI-only APK.
The next stage is to integrate the Hindi model and Saffron UI.
